from django.contrib import admin
from admin_scripts.complex_app.models.foo import Foo
admin.site.register(Foo)
