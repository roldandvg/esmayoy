from error_messages import *
from extra import *
from fields import FieldsTests
from forms import *
from formsets import *
from input_formats import *
from media import *
from models import *
from regressions import *
from util import *
from validators import TestFieldWithValidators
from widgets import *

from regressiontests.forms.localflavortests import (
    ARLocalFlavorTests, ATLocalFlavorTests, AULocalFlavorTests,
    BRLocalFlavorTests, CALocalFlavorTests, CHLocalFlavorTests,
    CLLocalFlavorTests, CZLocalFlavorTests, DELocalFlavorTests,
    ESLocalFlavorTests, FILocalFlavorTests, FRLocalFlavorTests,
    GenericLocalFlavorTests, IDLocalFlavorTests, IELocalFlavorTests,
    ISLocalFlavorTests, ITLocalFlavorTests, JPLocalFlavorTests,
    KWLocalFlavorTests, NLLocalFlavorTests, PLLocalFlavorTests,
    PTLocalFlavorTests, ROLocalFlavorTests, SELocalFlavorTests,
    SKLocalFlavorTests, UKLocalFlavorTests, USLocalFlavorTests,
    UYLocalFlavorTests, ZALocalFlavorTests
)
