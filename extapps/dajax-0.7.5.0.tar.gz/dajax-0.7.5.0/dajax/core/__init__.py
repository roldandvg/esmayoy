from Dajax import Dajax
from DajaxRequest import DajaxRequest