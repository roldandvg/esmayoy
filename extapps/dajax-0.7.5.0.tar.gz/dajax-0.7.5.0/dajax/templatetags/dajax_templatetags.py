from django import template
from dajax.core import DajaxRequest

register = template.Library()

@register.inclusion_tag('dajax/dajax_js_import.html',takes_context=True)
def dajax_js_import(context):
	return { 'DAJAX_MEDIA_PREFIX': DajaxRequest.get_media_prefix() }